# R1D Staking UI
This is the complete and verified frontend staking portal for the R1D DAO project, ready to deploy on Vercel.